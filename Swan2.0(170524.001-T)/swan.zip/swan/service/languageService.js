app.service('languageService', function() {
	this.langObj = {
		lang: "en"
	};
});